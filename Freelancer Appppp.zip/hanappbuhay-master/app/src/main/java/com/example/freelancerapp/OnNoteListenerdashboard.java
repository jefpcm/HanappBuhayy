package com.example.freelancerapp;

public interface OnNoteListenerdashboard {
    void onItemClicked(User user);
}
