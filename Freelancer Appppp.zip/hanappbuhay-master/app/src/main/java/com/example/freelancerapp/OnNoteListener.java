package com.example.freelancerapp;

public interface OnNoteListener {
    void onItemClicked(User user);
}
